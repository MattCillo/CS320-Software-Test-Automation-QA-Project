/** Author: Matthew Cillo */
package appointment;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment a) {
        if (a == null || appointments.containsKey(a.getAppointmentId())) throw new IllegalArgumentException("Error");
        appointments.put(a.getAppointmentId(), a);
    }

    public void deleteAppointment(String id) {
        if (!appointments.containsKey(id)) throw new IllegalArgumentException("Not found");
        appointments.remove(id);
    }

    public Appointment getAppointment(String id) { return appointments.get(id); }
}