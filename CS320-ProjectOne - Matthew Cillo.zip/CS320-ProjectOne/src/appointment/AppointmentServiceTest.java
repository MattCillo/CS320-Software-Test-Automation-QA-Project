/** Author: Matthew Cillo */
package appointment;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import java.util.Date;

public class AppointmentServiceTest {
    @Test
    void testServiceFull() {
        AppointmentService as = new AppointmentService();
        Appointment a = new Appointment("1", new Date(System.currentTimeMillis() + 50000), "D");
        
        as.addAppointment(a);
        Assertions.assertThrows(IllegalArgumentException.class, () -> as.addAppointment(a));
        Assertions.assertNotNull(as.getAppointment("1"));
        
        as.deleteAppointment("1");
        Assertions.assertThrows(IllegalArgumentException.class, () -> as.deleteAppointment("1"));
    }
}