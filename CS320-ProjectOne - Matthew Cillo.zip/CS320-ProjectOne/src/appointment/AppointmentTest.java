/** Author: Matthew Cillo */
package appointment;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import java.util.Date;

public class AppointmentTest {
    @Test
    void testApptFull() {
        Date future = new Date(System.currentTimeMillis() + 1000000);
        Appointment a = new Appointment("1", future, "Desc");
        
        // Verify Getters
        Assertions.assertEquals("1", a.getAppointmentId());
        Assertions.assertEquals(future, a.getAppointmentDate());
        Assertions.assertEquals("Desc", a.getDescription());

        // Failure Branches
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment(null, future, "D"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("1", null, "D"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("1", new Date(0), "D"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("1", future, null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Appointment("1", future, "This description is just way too long for the limit to handle."));
    }
}