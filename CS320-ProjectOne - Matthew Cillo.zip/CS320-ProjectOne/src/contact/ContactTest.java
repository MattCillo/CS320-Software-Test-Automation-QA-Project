/** Author: Matthew Cillo */
package contact;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

public class ContactTest {
    @Test
    void testContactFull() {
        Contact c = new Contact("1", "Matt", "Cillo", "1234567890", "123 Main St");
        
        // Constructor & Update Success (Covers Getters)
        Assertions.assertEquals("1", c.getContactId());
        c.updateFirstName("John");
        Assertions.assertEquals("John", c.getFirstName());
        c.updateLastName("Doe");
        Assertions.assertEquals("Doe", c.getLastName());
        c.updatePhone("0987654321");
        Assertions.assertEquals("0987654321", c.getPhone());
        c.updateAddress("New St");
        Assertions.assertEquals("New St", c.getAddress());

        // Branch Coverage: Constructor Failures
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact(null, "M", "C", "1234567890", "A"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "M", "C", "1234567890", "A"));
        
        // Branch Coverage: Update Failures (Hits all 'if' branches)
        Assertions.assertThrows(IllegalArgumentException.class, () -> c.updateFirstName(null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> c.updateFirstName("NameTooLong"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> c.updateLastName(null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> c.updateLastName("NameTooLong"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> c.updatePhone(null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> c.updatePhone("123")); // Too short
        Assertions.assertThrows(IllegalArgumentException.class, () -> c.updatePhone("12345678901")); // Too long
        Assertions.assertThrows(IllegalArgumentException.class, () -> c.updatePhone("ABC1234567")); // Regex fail
        Assertions.assertThrows(IllegalArgumentException.class, () -> c.updateAddress(null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> c.updateAddress("This address is intentionally too long for coverage."));
    }
}