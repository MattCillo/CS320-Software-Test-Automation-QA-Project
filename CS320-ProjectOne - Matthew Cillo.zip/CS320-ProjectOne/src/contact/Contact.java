/** Author: Matthew Cillo */
package contact;

public class Contact {
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String id, String first, String last, String phone, String addr) {
        if (id == null || id.length() > 10) throw new IllegalArgumentException("Invalid ID");
        this.contactId = id;
        updateFirstName(first);
        updateLastName(last);
        updatePhone(phone);
        updateAddress(addr);
    }

    public void updateFirstName(String first) {
        if (first == null || first.length() > 10) throw new IllegalArgumentException("Invalid First Name");
        this.firstName = first;
    }

    public void updateLastName(String last) {
        if (last == null || last.length() > 10) throw new IllegalArgumentException("Invalid Last Name");
        this.lastName = last;
    }

    public void updatePhone(String phone) {
        if (phone == null || phone.length() != 10 || !phone.matches("\\d+")) throw new IllegalArgumentException("Invalid Phone");
        this.phone = phone;
    }

    public void updateAddress(String addr) {
        if (addr == null || addr.length() > 30) throw new IllegalArgumentException("Invalid Address");
        this.address = addr;
    }

    public String getContactId() { return contactId; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }
}