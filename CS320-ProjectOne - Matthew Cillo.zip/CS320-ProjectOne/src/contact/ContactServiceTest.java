/** Author: Matthew Cillo */
package contact;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

public class ContactServiceTest {
    @Test
    void testServiceFull() {
        ContactService cs = new ContactService();
        Contact c = new Contact("1", "M", "C", "1234567890", "A");
        cs.addContact(c);
        
        // Success Path for ALL Service Updates
        cs.updateFirstName("1", "John");
        cs.updateLastName("1", "Doe");
        cs.updatePhone("1", "0987654321");
        cs.updateAddress("1", "New Ave");
        Assertions.assertNotNull(cs.getContact("1"));

        // Failure Path for ALL Service Updates (Hits "Not Found" branches)
        Assertions.assertThrows(IllegalArgumentException.class, () -> cs.addContact(c)); // Duplicate
        Assertions.assertThrows(IllegalArgumentException.class, () -> cs.updateFirstName("99", "N"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> cs.updateLastName("99", "N"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> cs.updatePhone("99", "1234567890"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> cs.updateAddress("99", "A"));
        
        // Delete Branch
        cs.deleteContact("1");
        Assertions.assertThrows(IllegalArgumentException.class, () -> cs.deleteContact("1"));
    }
}