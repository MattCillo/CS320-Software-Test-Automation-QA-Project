/** Author: Matthew Cillo */
package contact;
import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact c) {
        if (c == null || contacts.containsKey(c.getContactId())) throw new IllegalArgumentException("Duplicate ID");
        contacts.put(c.getContactId(), c);
    }

    public void deleteContact(String id) {
        if (!contacts.containsKey(id)) throw new IllegalArgumentException("Not found");
        contacts.remove(id);
    }

    public void updateFirstName(String id, String first) {
        if (!contacts.containsKey(id)) throw new IllegalArgumentException("Not found");
        contacts.get(id).updateFirstName(first);
    }

    public void updateLastName(String id, String last) {
        if (!contacts.containsKey(id)) throw new IllegalArgumentException("Not found");
        contacts.get(id).updateLastName(last);
    }

    public void updatePhone(String id, String phone) {
        if (!contacts.containsKey(id)) throw new IllegalArgumentException("Not found");
        contacts.get(id).updatePhone(phone);
    }

    public void updateAddress(String id, String addr) {
        if (!contacts.containsKey(id)) throw new IllegalArgumentException("Not found");
        contacts.get(id).updateAddress(addr);
    }

    public Contact getContact(String id) { return contacts.get(id); }
}