/** Author: Matthew Cillo */
package task;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

public class TaskServiceTest {
    @Test
    void testServiceFull() {
        TaskService ts = new TaskService();
        Task t = new Task("1", "N", "D");
        ts.addTask(t);
        
        // Updates Success
        ts.updateName("1", "New");
        ts.updateDescription("1", "NewD");
        
        // Updates Failure (Not Found)
        Assertions.assertThrows(IllegalArgumentException.class, () -> ts.updateName("99", "N"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> ts.updateDescription("99", "D"));
        
        // Delete
        ts.deleteTask("1");
        Assertions.assertThrows(IllegalArgumentException.class, () -> ts.deleteTask("1"));
    }
}