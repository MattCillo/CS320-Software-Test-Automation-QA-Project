/** Author: Matthew Cillo */
package task;
import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task t) {
        if (t == null || tasks.containsKey(t.getTaskId())) throw new IllegalArgumentException("Error");
        tasks.put(t.getTaskId(), t);
    }

    public void deleteTask(String id) {
        if (!tasks.containsKey(id)) throw new IllegalArgumentException("Not found");
        tasks.remove(id);
    }

    public void updateName(String id, String name) {
        if (!tasks.containsKey(id)) throw new IllegalArgumentException("Not found");
        tasks.get(id).updateName(name);
    }

    public void updateDescription(String id, String desc) {
        if (!tasks.containsKey(id)) throw new IllegalArgumentException("Not found");
        tasks.get(id).updateDescription(desc);
    }

    public Task getTask(String id) { return tasks.get(id); }
}