/** Author: Matthew Cillo */
package task;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

public class TaskTest {
    @Test
    void testTaskFull() {
        Task t = new Task("1", "Name", "Desc");
        Assertions.assertEquals("1", t.getTaskId());
        
        // Success Updates
        t.updateName("New");
        t.updateDescription("NewDesc");
        Assertions.assertEquals("New", t.getName());
        Assertions.assertEquals("NewDesc", t.getDescription());

        // Failure Branches
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(null, "N", "D"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "N", "D"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> t.updateName(null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> t.updateName("NameIsWayTooLongForThis"));
        Assertions.assertThrows(IllegalArgumentException.class, () -> t.updateDescription(null));
        Assertions.assertThrows(IllegalArgumentException.class, () -> t.updateDescription("This description is intentionally very long to hit the fifty char limit."));
    }
}