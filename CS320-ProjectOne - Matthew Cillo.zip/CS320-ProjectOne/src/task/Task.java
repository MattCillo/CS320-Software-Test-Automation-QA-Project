/** Author: Matthew Cillo */
package task;

public class Task {
    private final String taskId;
    private String name;
    private String description;

    public Task(String id, String name, String desc) {
        if (id == null || id.length() > 10) throw new IllegalArgumentException("Invalid ID");
        this.taskId = id;
        updateName(name);
        updateDescription(desc);
    }

    public void updateName(String name) {
        if (name == null || name.length() > 20) throw new IllegalArgumentException("Invalid Name");
        this.name = name;
    }

    public void updateDescription(String desc) {
        if (desc == null || desc.length() > 50) throw new IllegalArgumentException("Invalid Description");
        this.description = desc;
    }

    public String getTaskId() { return taskId; }
    public String getName() { return name; }
    public String getDescription() { return description; }
}